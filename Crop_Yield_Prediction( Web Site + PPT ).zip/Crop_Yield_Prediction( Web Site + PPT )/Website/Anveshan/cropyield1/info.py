EMAIL_USE_TLS = True
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'jai20070@iiitd.ac.in'
EMAIL_HOST_PASSWORD = 'user@123'
EMAIL_PORT = 587

